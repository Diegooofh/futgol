<html>
<head>
<title>Futgol</title>
<meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
<link rel="shortcut icon" href="favicon.ico" />
</head>

<body>
<img align="right" src="logo1.jpeg" class='logovale'>
<h1 align="left">¡Consulta los goles de tus jugadores favoritos!</h1>
<h2 align="left" > Inicia sesión para continuar</h2>
<div>
<form action="sesion2.php" method="GET">
	<p>Usuario <input type="text" name="usuario"></p>
	<p>Contraseña <input type="password" name="pass"></p>
	<p><input type="submit" name="Validar"></p>
</form>
</div>
</body>
</html>